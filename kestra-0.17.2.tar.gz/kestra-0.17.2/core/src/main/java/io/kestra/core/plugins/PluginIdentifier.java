package io.kestra.core.plugins;


/**
 * Represents the fully qualify identifier of a Kestra's plugin.
 */
public interface PluginIdentifier { }
