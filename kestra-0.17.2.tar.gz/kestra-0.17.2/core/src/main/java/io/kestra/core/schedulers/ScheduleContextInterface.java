package io.kestra.core.schedulers;

public interface ScheduleContextInterface {
}
