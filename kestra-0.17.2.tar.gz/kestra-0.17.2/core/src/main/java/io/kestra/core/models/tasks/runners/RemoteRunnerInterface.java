package io.kestra.core.models.tasks.runners;

public interface RemoteRunnerInterface {}
