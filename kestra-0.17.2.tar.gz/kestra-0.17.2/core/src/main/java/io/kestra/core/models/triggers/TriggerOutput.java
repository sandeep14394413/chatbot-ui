package io.kestra.core.models.triggers;

import io.kestra.core.models.tasks.Output;

public interface TriggerOutput<T extends Output> {

}
