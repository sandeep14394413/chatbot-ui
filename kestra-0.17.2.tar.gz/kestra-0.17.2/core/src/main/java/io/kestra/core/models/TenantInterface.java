package io.kestra.core.models;

public interface TenantInterface {
    String getTenantId();
}
