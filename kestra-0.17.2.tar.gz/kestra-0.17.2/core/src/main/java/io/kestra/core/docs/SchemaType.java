package io.kestra.core.docs;

public enum SchemaType {
    flow,
    template,
    task,
    trigger,
    plugindefault
}
