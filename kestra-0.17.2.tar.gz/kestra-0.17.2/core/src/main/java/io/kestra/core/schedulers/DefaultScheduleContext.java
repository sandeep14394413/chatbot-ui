package io.kestra.core.schedulers;

// For tests purpose
public class DefaultScheduleContext implements ScheduleContextInterface {}
