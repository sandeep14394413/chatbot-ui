package io.kestra.core.models;

public enum  ServerType {
    EXECUTOR,
    INDEXER,
    SCHEDULER,
    STANDALONE,
    WEBSERVER,
    WORKER,
}
