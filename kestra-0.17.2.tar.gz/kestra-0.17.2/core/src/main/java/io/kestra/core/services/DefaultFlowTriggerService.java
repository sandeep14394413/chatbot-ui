package io.kestra.core.services;

import jakarta.inject.Singleton;

@Singleton
public class DefaultFlowTriggerService extends AbstractFlowTriggerService {
}