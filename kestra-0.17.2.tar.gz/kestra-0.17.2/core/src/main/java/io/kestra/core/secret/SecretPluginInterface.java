package io.kestra.core.secret;

import io.kestra.core.models.annotations.Plugin;

@Plugin
public interface SecretPluginInterface extends io.kestra.core.models.Plugin {

}
