package io.kestra.core.runners;

import java.io.Closeable;

public interface IndexerInterface extends Runnable, Closeable {

}
