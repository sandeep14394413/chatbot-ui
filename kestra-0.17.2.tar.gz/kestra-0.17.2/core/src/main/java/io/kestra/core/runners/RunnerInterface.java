package io.kestra.core.runners;

public interface RunnerInterface {
    void run();
}
