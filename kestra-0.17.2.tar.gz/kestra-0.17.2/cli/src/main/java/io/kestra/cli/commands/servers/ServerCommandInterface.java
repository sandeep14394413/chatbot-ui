package io.kestra.cli.commands.servers;

public interface ServerCommandInterface {
}
